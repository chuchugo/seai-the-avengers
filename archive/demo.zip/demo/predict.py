
class RecommendationModel:
    def __init__(self, model_path):
        self.model = None

    def predict_recommendation(self, userid):
        recommend_list = [1,2,3,4,5]
        return recommend_list
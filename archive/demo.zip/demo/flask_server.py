from flask import Flask
from flask import jsonify
from flask import request
from predict import RecommendationModel

app = Flask(__name__)
recommendationModel = RecommendationModel("fake_path")

@app.route('/', methods=['GET'])
def hello_world():
    return jsonify({'message' : 'It works!'})

@app.route('/recommend/<string:userid>', methods=['GET'])
def recommend(userid):
    rcmd_res = recommendationModel.predict_recommendation(userid)
    return jsonify({
        'status':200, 
        'user id' : userid,
        'result':rcmd_res,
        })

if __name__ == "__main__":
    app.run(debug=True)